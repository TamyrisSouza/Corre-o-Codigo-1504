package org.senai.exemplos;


public  class Funcionario {
    protected String nome;
    protected double salario;
    protected double percentual;

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public double calcularBonus(double percentual) {
        this.percentual = percentual;
        return salario * percentual;
    }

    public void mostrarDados() {

        System.out.println("Nome: " + nome + " | Salário: " + salario + "Bônus: " + );
    }
}
