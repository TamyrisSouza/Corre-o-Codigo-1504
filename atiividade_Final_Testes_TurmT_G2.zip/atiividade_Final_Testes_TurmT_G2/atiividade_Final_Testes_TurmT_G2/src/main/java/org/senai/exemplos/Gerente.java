package org.senai.exemplos;

public class Gerente{
    private double bonusExtra;
    private double percentual;
    private double salario;
    private String nome;

    public double calcularBonus(double percentual) {
        this.percentual = percentual;
        // ERRO: variável não existe
        return salario * percentual;
    }

    public void mostrarBonus() {

        System.out.println("Bônus extra: " + bonusExtra);
    }
}
