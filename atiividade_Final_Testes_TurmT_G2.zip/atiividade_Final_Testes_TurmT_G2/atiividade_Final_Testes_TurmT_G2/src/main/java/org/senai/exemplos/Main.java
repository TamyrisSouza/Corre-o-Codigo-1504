package org.senai.exemplos;


public class Main {
    public static void main(String[] args) {
        Funcionario func1 = new Funcionario("Priscila", 1000);
        func1.mostrarDados();

        Gerente func2 = new Gerente();
        System.out.println("Bônus: " + func2.calcularBonus(1.0));

    }
}